import javax.swing.*;
import java.util.Objects;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //zad1();
        //zad4();
        //zad5();
        //zad6();
        //zad8();
        zad8v2();
    }

    static void zad1() {
        boolean czyPada = true, czySwieciSlonce = true;

        if (czyPada && !czySwieciSlonce) System.out.println("plucha");
        if (czyPada && czySwieciSlonce) System.out.println("tecza");
        if (!czyPada && czySwieciSlonce) System.out.println("slonecznie");
        if (!czyPada && !czySwieciSlonce) System.out.println("pochmurno");
    }

    static void zad4() {
        System.out.println("input 2 lines with ints, then 1 line" +
                " with command ADD, SUB, DIV or MUL");
        Scanner in = new Scanner(System.in);
        String line0 = in.nextLine();
        String line1 = in.nextLine();
        String command = in.nextLine();

        int number0 = Integer.parseInt(line0);
        int number1 = Integer.parseInt(line1);
        int result;

        switch (command) {
            case "ADD": {
                result = number0 + number1;
                System.out.println("Wynik: " + result);
            }
            break;
            case "SUB": {
                result = number0 - number1;
                System.out.println("Wynik: " + result);
            }
            break;
            case "DIV": {
                result = number0 / number1;
                System.out.println("Wynik: " + result);
            }
            break;
            case "MUL": {
                result = number0 * number1;
                System.out.println("Wynik: " + result);
            }
            break;

            default:
                System.out.println("brak takiej operacji");
        }
    }

    static void zad5() {
        System.out.println("input 2 lines with ints, then 1 line" +
                " with command ADD, SUB, DIV or MUL");
        Scanner in = new Scanner(System.in);
        String line0 = in.nextLine();
        String line1 = in.nextLine();
        String command = in.nextLine();

        int number0 = Integer.parseInt(line0);
        int number1 = Integer.parseInt(line1);
        int result;

        switch (command) {
            case "ADD": {
                result = number0 + number1;
                System.out.println("Wynik: " + absoluteValue(result));
            }
            break;

            case "SUB": {
                result = number0 - number1;
                System.out.println("Wynik: " + absoluteValue(result));
            }
            break;

            case "DIV": {
                result = number0 / number1;
                System.out.println("Wynik: " + absoluteValue(result));
            }
            break;

            case "MUL": {
                result = number0 * number1;
                System.out.println("Wynik: " + absoluteValue(result));
            }
            break;

            default:
                System.out.println("brak takiej operacji");
        }
    }

    static int absoluteValue(int input) {
        if (input < 0) return input * (-1);
        else return input;
    }

    static void zad6() {
        System.out.println("input 2 real numbers");
        Scanner in = new Scanner(System.in);

        String line0 = in.nextLine();
        String line1 = in.nextLine();

        double a = Double.parseDouble(line0);
        double b = Double.parseDouble(line1);

        if (!(a < b)) {
            double proxy = a;
            a = b;
            b = proxy;
        }

        System.out.println("przedzial: [" + a + ", " + b + "]");

        // Math.random * (max - min + 1) + min
        double d1 = Math.random() * (b - a + 1) + a;
        double d2 = Math.random() * (b - a + 1) + a;
        double d3 = Math.random() * (b - a + 1) + a;

        System.out.println("wartosci generowane losowo: "
                + d1 + "\n"
                + d2 + "\n"
                + d3);

        if (d1 > d2) {
            double proxy = d1;
            d1 = d2;
            d2 = proxy;
        }
        if (d2 > d3) {
            double proxy = d2;
            d2 = d3;
            d3 = proxy;
        }
        if (d1 > d2) {
            double proxy = d1;
            d1 = d2;
            d2 = proxy;
        }

        System.out.println("Gdzie: " + d1 + " < " + d2 + " < " + d3);
    }

    static void zad8() {
        double rate = 30.31; // 1 pln = 30 yen

        Scanner in = new Scanner(System.in);
        System.out.println("Witamy w kantorze! + \nWybierz walute:\n" +
                "\t1 - PLM\n\t2 - JPY");

        String currency = in.nextLine();

        System.out.println("wprowadz kwote:");

        double value = Double.parseDouble(in.nextLine());

        if (currency.equals("1")) {
            System.out.println(value + " zl => " + get2Decimals(value * rate));
        } else if (currency.equals("2")) {
            System.out.println(value + " ¥ => " + get2Decimals(value * (1 / rate)));
        } else {
            System.out.println("wrong currency");
        }
    }

    static void zad8v2() {
        double rate = 30.31; // 1 pln = 30 yen
        Object[] options = {"PLN", "JPY"};

        int currency = JOptionPane.showOptionDialog(
                null, "jaka masz monete?", "KANTOR", JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, options, 666);

        String input = JOptionPane.showInputDialog(null, "ile masz monet?`");
        double value = Double.parseDouble(input);

        if (currency == 0) { // pln to jpy
            double converted = rate * value;
            converted = get2Decimals(converted);
            JOptionPane.showMessageDialog(null, value + " zl => " + converted + " ¥");
        }
        if (currency == 1) { // jpy to pln
            double converted = (1/rate) * value;
            converted = get2Decimals(converted);
            JOptionPane.showMessageDialog(null, value + " ¥ => " + converted + " zl");
        }

    }

    static double get2Decimals(double d) {
        double result = (int)(d * 100);
        return result / 100;
    }
}
